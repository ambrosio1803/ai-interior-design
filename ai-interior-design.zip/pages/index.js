import { useState } from 'react'
import ImageUploadForm from '@/components/ImageUploadForm'
import ResultDisplay from '@/components/ResultDisplay'
import DesignStyleSelector from '@/components/DesignStyleSelector'

export default function Home() {
  const [imageUrl, setImageUrl] = useState(null)
  const [resultUrl, setResultUrl] = useState(null)
  const [style, setStyle] = useState('minimalist')

  return (
    <div className="min-h-screen bg-gray-100 p-6 text-center">
      <h1 className="text-4xl font-bold mb-4">Diseño de Interiores con IA</h1>
      <p className="mb-6">Sube una imagen y transforma tu espacio con inteligencia artificial.</p>
      <DesignStyleSelector style={style} setStyle={setStyle} />
      <ImageUploadForm setImageUrl={setImageUrl} setResultUrl={setResultUrl} style={style} />
      <ResultDisplay original={imageUrl} result={resultUrl} />
    </div>
  )
}
